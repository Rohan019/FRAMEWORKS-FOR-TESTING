package Automation_Cucumber.EvaluationCucumber;

public class App {
  public static void main(String[] args) {
    System.out.println("Hello World!");
  }
}
