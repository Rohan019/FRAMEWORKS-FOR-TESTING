
public class demo1 {
	
	public static void gdm(){
		System.out.println("welcome to automation testing");
		
	}

	public static void main(String[] args) {
		System.out.println("MB");
		gdm();
		System.out.println("ME");
	}

}
