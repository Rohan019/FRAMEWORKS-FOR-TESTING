
public class Class_loading_process {
	
	static int i;
	static double j;
	
	static {
		System.out.println("SIB-1");		
	}
	
	public static void demo() {
		System.out.println("welcome");
		System.out.println("i: "+i);
		System.out.println("j: "+j);
		i=13;
		j=50;
	}
	
	public static void test() {
		System.out.println("welcome");
		System.out.println("i: "+i);
		//System.out.println("j: "+j);
		i=10;
		j=90;
	}

	public static void main(String[] args) {
		System.out.println("MB");
		test();
		System.out.println("i: "+i);
		System.out.println("j: "+j);
	}
	
	static {
		System.out.println("SIB-2");
		demo();
	}
	

}
