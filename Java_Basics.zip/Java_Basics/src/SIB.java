
public class SIB {
	static {
		System.out.println("Sib1");
	}

	public static void main(String[] args) {
		System.out.println("MB");
	}
	
	static {
		System.out.println("Sib2");
	}
	

}
