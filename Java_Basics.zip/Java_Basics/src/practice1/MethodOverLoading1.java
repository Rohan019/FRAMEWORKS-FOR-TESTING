package practice1;

public class MethodOverLoading1 {
	
	public static int test(int a, int b) {
		System.out.println("Main Begins");
	    int c=a+b;
	    return c;
	}
	
	public static int test(int a, int b, int d) {
		System.out.println("Main Begins");
	    int c=a*b;
	    return c;
	}
	
	
	public static void main (String args[]) {
		System.out.println("Main ends");
		int Z = test(10,20);
		int x = test(9,9,9);
		
		System.out.println(Z);
		System.out.println(x);
		
		
	}

}
