package practice1;

public class CountCharacterOccurence {
	public static void main(String[] args) {
		String str = "Shivashish";
		
		int i = str.length()-str.replaceAll("h", "").length();
		System.out.println("The length of the string will be: "+i);
	}

}
