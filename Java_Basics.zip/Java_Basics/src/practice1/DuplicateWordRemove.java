package practice1;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class DuplicateWordRemove {

	public static void main(String[] args) {
		String input = "I am am Rohan as aa qa tester tester";
		
		String[] inputarr = input.split(" "); // Split the string by spaces,and we got the array
		
		Set<String> myset = new LinkedHashSet<String>();
		
		for(String x:inputarr) {
			myset.add(x);
		}
		
		Iterator itr = myset.iterator();
		
		while(itr.hasNext()) {
			System.out.print(itr.next() + " ");
		}
			
		
	}

}
