
public class Arguments {
	
	public static int multiply(int a, int b) {
		int c=a*b;
		return c;
		
	}

	public static void main(String[] args) {
		int d =multiply(4,5);
		System.out.println(d);
	}
	

}
