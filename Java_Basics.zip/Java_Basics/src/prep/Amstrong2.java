package prep;

import java.util.*;
public class Amstrong2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Entr the number");
		int m1=sc.nextInt();
		int length=0; int p1;
		p1=m1;
		while(p1!=0) {
			length=length+1;
			p1=p1/10;
		}
		
		int p2; int rem; int arm=0;
		p2=m1;
		while(p2!=0) {
			int mul=1;
			rem=p2%10;
			for(int i=1;i<=length;i++) {
				mul=mul*rem;
			}
			arm=arm+mul;
			p2=p2/10;			
			
		}
		if(arm==m1) {
			System.out.println("It is amstrong");
		}
		else {
			System.out.println("It is not an amstrong");
		}
		

	}

}
