package prep;

class Employee{
	private int id;
	
	public void setEmpid(int eid){
		id = eid;
	}
	
	public int getEmpid() {
		return id;
	}
}


public class Company {

	public static void main(String[] args) {
		Employee e = new Employee();
		e.setEmpid(101);
		System.out.println(e.getEmpid());
	}

}
