package prep;

class car{
	private String Formula_car;
	
	public void setCar(String car1) {
		Formula_car = car1;
		
	}
	
	public String getCar() {
		return Formula_car;
	}
}

public class Driver {
	public static void main(String args[]) {
		car c1 = new car();
		c1.setCar("tata");
		System.out.println(c1.getCar());
	}
	

}
