package prep;

abstract class Instagram {
	abstract public void login();
}

class insta extends Instagram {
	public void login() {
		System.out.println("Updating the insta");
	}
}

public class DriverB {

	public static void main(String[] args) {
		Instagram ref = new insta();
		ref.login();
	}

}
