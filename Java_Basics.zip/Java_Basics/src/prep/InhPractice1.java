package prep;

class A {
	int i = 10;
	{
		System.out.println("IIB of superclass");
	}
}

class B extends A{
	int j = 20;
	{
		System.out.println("IIB of subclass");
	}
}

public class InhPractice1 {

	public static void main(String[] args) {
		System.out.println("Main Begins");
		A ref = new A();
		System.out.println(ref.i);
		System.out.println("Main Ends");
		
	}

}
