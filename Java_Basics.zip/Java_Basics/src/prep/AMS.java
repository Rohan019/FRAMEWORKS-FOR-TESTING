package prep;

import java.util.Scanner;
public class AMS {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number please");
		int n1 = sc.nextInt();
		int t1; int length =0;
		 t1 = n1;  // 153
		 while (t1!=0) {
			 length = length+1;
			 t1=t1/10;
		 }
		 
		 int t2; int arm=0; int rem;
		 t2 = n1;
		 while(t2!=0) {
			 int mul = 1;
			 rem = t2%10;
			 for(int i=1;i<=length;i++) {
				mul=mul*rem;
			 }
			 arm=arm+mul;
			 t2=t2/10;
		 }
		 if(arm==n1) {
			 System.out.println("It is armstrong no");
		 }
		 else {
			 System.out.println("It is not an amstrong no");
		 }
		 
		
		
	
	}

}
