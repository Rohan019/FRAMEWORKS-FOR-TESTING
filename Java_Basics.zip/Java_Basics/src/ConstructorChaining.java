
public class ConstructorChaining {
	String name;
	int id;
	
	ConstructorChaining(){
		System.out.println("MV");
	}
	
	ConstructorChaining(String name){
		this();
		this.name=name;
		System.out.println("MB");
	}
	
	ConstructorChaining(String name, int id){
		this(name);
		this.id=id;
		System.out.println("Mn");
	}

	public static void main(String[] args) {
		ConstructorChaining c1 = new ConstructorChaining("rhaul",19);
		System.out.println("name is: "+c1.name);
		System.out.println("id is: "+c1.id);
		
	}

}
