package stepdefinition;


import java.io.IOException;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import pageobject.PageObject;

public class Stepdefinition {
	PageObject po;
	   
	   @Before
	   public void init() throws IOException
	   {    
		   po = new PageObject();
	   }

	   @Given("user is on the provida application")
	   public void user_is_on_the_provida_application() {
		   po.gettitle();
	   }

	   @Given("user enter RUT Username {string}")
	   public void user_enter_RUT_Username(String string) {
	       po.rut(string);
	   }

	   @Then("click on Submit button")
	   public void click_on_Submit_button() {
	      po.submit();
	   }

	   @Then("enter password {string}")
	   public void enter_password(String string) {
	      po.password(string);
	   }

	   @Then("click on enter button")
	   public void click_on_enter_button() {
	      po.submitbutton();
	   }
	   
	   
/*----------------------------TRY WITH ANOTHER RUT-------------------------------------*/
	   
	   
	   
	   @Given("user enter RUT username {string}")
	   public void user_enter_RUT_username(String string) {
	       po.rut(string);
	   }

	   @Then("user click on enter button")
	   public void user_click_on_enter_button() {
	       po.submit();
	   }

	  
	   



}
