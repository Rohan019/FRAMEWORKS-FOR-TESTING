package pageobject;

import java.io.IOException;
import java.sql.Driver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseconnection.Connection;


public class PageObject extends Connection {
	
	@FindBy(xpath ="//input[@id=\"USER\"]")
	WebElement RUT ;
	
	@FindBy(xpath ="//button[@id=\"loginFormSubmit\"]")
	WebElement submit ;
	
	
	@FindBy(xpath = "//input[@id=\"PASSWORD\"]")
	WebElement password ;
	
	@FindBy(xpath = "//button[@id=\"loginFormSubmit\"]")
	WebElement login ;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div/div[1]/div/form/div[4]/a[2]/font/font")
	WebElement another_rut ;
	
	
	
	public PageObject() throws IOException {
		setup();
		PageFactory.initElements(driver, this);
	}

	public void gettitle() {
		String title = driver.getTitle();
		System.out.println(title);
	}

	public void rut(String string) {
		RUT.sendKeys(string);		
	}

	public void submit() {
		submit.click();
	}

	public void password(String string) {
		password.sendKeys(string);
	}

	public void submitbutton() {
		login.click();
	}

	
	



	



	

	
	
	
	

}
