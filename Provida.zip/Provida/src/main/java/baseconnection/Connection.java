package baseconnection;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Connection {
	public static	WebDriver driver ;


	
	public  void setup() throws IOException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\RSHERBAH\\eclipse-workspace\\Provida\\target\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.get("https://qa.identity.provida.cl");
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
	} 
}
