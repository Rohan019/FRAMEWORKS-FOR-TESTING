package testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features ="C:\\Users\\RSHERBAH\\eclipse-workspace\\Provida\\src\\main\\java\\feature\\provida.feature" 
, glue ="stepdefinition" ,monochrome = true , plugin = {"pretty"})
public class Testrunner {

}
