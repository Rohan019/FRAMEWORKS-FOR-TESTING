
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import com.intuit.karate.junit4.Karate;

@RunWith(Karate.class)
public class TestRunner2 {
	
	@BeforeClass
	public static void before() {
		System.setProperty("karate.env", "qa");
	}

}
