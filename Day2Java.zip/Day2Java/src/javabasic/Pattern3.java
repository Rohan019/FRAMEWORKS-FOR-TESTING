package javabasic;

import java.util.Scanner;

public class Pattern3 {
	 public static void main(String args[])
	 {
		 int i,j;
			Scanner scanner = new Scanner(System.in);
	        // Get the number of rows from the user
	        System.out.println("Enter the number of rows to print the pattern:");
	        int rows = scanner.nextInt();
	        for(i=1;i<=rows;i++)
	        {
	        	for (j=1*(rows-i); j>=0; j--)         
	        	{
	        	System.out.print(" ");   
	        	}
	        	for(j=1;j<=i;j++)
	  	         {
	  	             System.out.print(rows-i+1);
	  	         }
	        	System.out.println(" ");
	  	     }
	 }

}
