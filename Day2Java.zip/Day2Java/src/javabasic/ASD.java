package javabasic;

import java.util.Scanner;

public class ASD {
	public static void main(String[] args)
	{
		char ch;
		Scanner sc=new Scanner(System.in);
		System.out.println("Eneter the character: ");
		ch=sc.nextLine().charAt(0);
		if((ch>=59 && ch<=90)) {
			System.out.println("\n It is a capital letter");
		}
		else if((ch>=97 && ch<=122)) {
			System.out.println("\n It is a small letter");
		}
		else if((ch>=48 && ch<=57)) {
			System.out.println("\n It is a digit");
		}
		else  {
			System.out.println("\n It is a special character");
		}
	}
	
	
}
