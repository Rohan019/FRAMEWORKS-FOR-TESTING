package javabasic;

import java.util.Scanner;

public class Maxint {
public static void main(String[] args) {
		
		int a, b, c, max;
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st number: ");
		a = sc.nextInt();
		System.out.println("Enter 2nd number: ");
		b = sc.nextInt();
		System.out.println("Enter 3rd number: ");
		c = sc.nextInt();
		max = a ;
		
		if(a<b) {
			if(c<b) {
				max = b;
			}
			else {
				max = c;
			}
		}
		
		System.out.println("Maximum is " + max);
		
	}



}
