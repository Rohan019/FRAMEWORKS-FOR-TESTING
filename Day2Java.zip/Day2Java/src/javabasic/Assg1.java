package javabasic;

import java.util.Scanner;

public class Assg1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a sentence: ");
		String s1= sc.nextLine();
		int intcount=0,floatcount=0,booleancount=0,stringcount=0;
		String[] words=s1.split("\\s");
		for(String w:words) {
			System.out.println(w);
	        if (w.matches("\\d+")) {
	        	intcount++;
	        }
	        else if (w.matches("\\d*[.]\\d+")) {
	        	floatcount++;
	        }
	        else if (w.matches("[Tt]rue|[Ff]alse")) {
	        	booleancount++;
	        }
	        else {
	        	stringcount++;
	        }
	        System.out.println(intcount + " " + floatcount + " " + booleancount + " " + stringcount);
		}
		System.out.println("Integer:" + intcount + "\nFloat " + floatcount + "\nBoolean " + booleancount + "\nString " + stringcount);
		
	}
	

}
