package collection;

import java.util.ArrayList;
import java.util.Collections;



public class Sorting {


	public static void main(String[] args) {
		ArrayList<Integer> a = new ArrayList<Integer>();
		System.out.println("The numbers are");
		a.add(1);
		a.add(2);
		a.add(8);
		a.add(4);
		a.add(9);
		a.add(6);
		System.out.println("Before sorting "+a);
		Collections.sort(a);
		System.out.println("Sorted list are "+a);
	}
	

}
