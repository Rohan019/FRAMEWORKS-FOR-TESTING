package collection;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class Customer {
	public static void main(String[] args) {
		ArrayList a = new ArrayList();
		a.add("customer1");
		a.add("customer2");
		a.add("customer3");
		a.add("customer2");
		a.add("customer5");
		a.add("customer1");
		System.out.println(a);
		
		String [] s= {"customer1","customer2","customer3","customer2",
				"customer5","customer1"};
		for(String m : s) {
			System.out.println(m);
			
		}
		System.out.println("\n");
		
	
		
		LinkedHashSet l=new LinkedHashSet();
		l.add("customer1");
		l.add("customer2");
		l.add("customer3");
		l.add("customer2");
		l.add("customer5");
		l.add("customer1");
		System.out.println("Customer without duplicate: "+l);
		
		
	}

}
