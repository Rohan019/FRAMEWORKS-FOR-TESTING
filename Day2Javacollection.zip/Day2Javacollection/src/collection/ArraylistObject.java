package collection;

import java.util.ArrayList;

class Document{
	int docid;
	String docname;
	String docsize;
	
	Document(int docid, String docname, String docsize)
	{
		this.docid=docid;
		this.docname=docname;
		this.docsize=docsize;
	}
	
}



public class ArraylistObject {
	public static void main(String[] args) {
		
		Document obj1=new Document(101, "doc1", "2mb");
		Document obj2=new Document(102, "doc2", "1mb");
		Document obj3=new Document(103, "doc3", "4mb");
		Document obj4=new Document(104, "doc4", "2mb");
		Document obj5=new Document(105, "doc5", "9mb");
		Document obj6=new Document(106, "doc6", "5mb");
		Document obj7=new Document(107, "doc17", "3mb");
		Document obj8=new Document(108, "doc16", "7mb");
		Document obj9=new Document(101, "doc1", "2mb");
		Document obj10=new Document(100, "doc1", "20mb");
		
		
		ArrayList<Document> list=new ArrayList<Document>();
		
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.add(obj4);
		list.add(obj5);
		list.add(obj6);
		list.add(obj7);
		list.add(obj8);
		list.add(obj9);
		list.add(obj10);
		
		
		for(Document ob :list)
		{
			System.out.println("Document Id: "+ob.docid);
			System.out.println("Document name: "+ob.docname);
			System.out.println("Document size: "+ob.docsize);
			
			System.out.println("-----------------------------");
		}
	}
	
	

}
