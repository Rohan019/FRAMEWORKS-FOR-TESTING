package test1;

import org.asynchttpclient.Response;

import io.restassured.RestAssured;

public class Example1 {
	
	public void test_1(){
		Response response = RestAssured.get("https://reqres.in/api/users?page=2");
		
		System.out.println(response.getStatusCode());
		
	}

}
