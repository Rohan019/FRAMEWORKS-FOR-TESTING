package Gurru99search;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Gurru99LS {
	
	WebDriver driver = null;
	
	@Given("browser is open")
	public void browser_is_open() {
	    // Write code here that turns the phrase above into concrete actions
		  System.out.println("Inside browser is open");
		    System.setProperty("webdriver.chrome.driver","C:\\Rohan Software\\Rohan STS\\CUjava\\src\\test\\resources\\drivers\\chromedriver.exe");
		    driver=new ChromeDriver();
		    driver.manage().window().maximize();
	}
	@Given("user navigate to the application")
	public void user_navigate_to_the_application() {
	    // Write code here that turns the phrase above into concrete actions
		   try {
		    	System.out.println("navigate to the application");
		    	
		    	driver.navigate().to("https://www.guru99.com/");
		    	Thread.sleep(3000);
		    	
		    }
		    
		    catch(Exception e) {
		    	System.out.println("user is unable to navigate to the application");
		    	
		    }
		    
		    
	}

	@Given("click on Testing dropdown")
	public void click_on_Testing_dropdown() {
	    // Write code here that turns the phrase above into concrete actions
	    try {
	    	System.out.println("user is able to go on testing dropdown");
	    	driver.findElement(By.xpath("//*[@id=\"menu-item-3173\"]/a/span")).click();
	    	Thread.sleep(3000);
	    }
	    
	    catch(Exception e) {
	    	System.out.println("user is unable to go on testing dropdown");
	    }
	}

	@Given("select selenium option")
	public void select_selenium_option() {
	    // Write code here that turns the phrase above into concrete actions
		   try {
		    	System.out.println("user is able to go on selenium option");
		    	driver.findElement(By.xpath("//a[text()='Selenium']")).click();
		    	Thread.sleep(3000);
		    }
		    
		    catch(Exception e) {
		    	System.out.println("user is unable to select the selenium option");
		    }
	}

	@Then("user navigate to search option")
	public void user_navigate_to_search_option() {
	    // Write code here that turns the phrase above into concrete actions
		try {
			Thread.sleep(3000);
			String expectedtitle = "Selenium Tutorial for Beginners: Learn WebDriver & Testing";
			String actualtitle = driver.getTitle();
			Assert.assertEquals(expectedtitle,actualtitle);
			System.out.println("You are able  to navigate to the page");
			driver.close();
			driver.quit();
		}
		
		catch(Exception e) {
			System.out.println("Not able to navigate to the  page"+e);
			Assert.fail();
		}
	    
	}



}
