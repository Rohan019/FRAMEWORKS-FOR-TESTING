import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.*;
import org.testng.annotations.Test;

public class Demo1_GetRequest {
 
	//@Test
	public void getweather() {
		baseURI = "https://reqres.in/api";
		given()
		.when()
			.get("/users?page=2")
		.then()
			.statusCode(200)
			.assertThat().body("email", equalTo("janet.weaver@reqres.in"));
			
			
	}
	
	@Test
	public void testpost() {
		Map <String, Object> map = new HashMap<String, Object>();
		
		map.put("name", "Rohan");
		map.put("job", "eng");
		
		System.out.println(map);
		
		JSONObject request = new JSONObject(map);
		System.out.println(request);
		
		
        baseURI = "https://reqres.in/api";
		
		given().
			header("Content-Type","application/json").
			body(request.toJSONString()).
		when().
			post("/users").
		then().
			statusCode(201);
	}
}
