import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class Demo2_Put_Patch {
	
	@Test
	public void testpost() {
		
		
		JSONObject request = new JSONObject();
		
		request.put("name", "Rohan");
		request.put("job","QA");
		
		System.out.println(request);
		
        baseURI = "https://reqres.in/api";
		
		given().
			header("Content-Type","application/json").
			body(request.toJSONString()).
		when().
			post("/users/2").
		then().
			statusCode(200).
			log().all();
	}
}
