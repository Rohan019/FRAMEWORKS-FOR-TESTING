package testrunner;





import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import io.cucumber.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions

(features="C:\\Users\\RSHERBAH\\eclipse-workspace\\CO_Registration\\src\\main\\java\\feature\\reg.feature", glue= {"Step_def","hook"},
plugin= {"pretty", "html:target/cucumber-pretty", "junit:target/report.xml", "json:target/cucumber.json"}  )
public class Testrunner {

}
