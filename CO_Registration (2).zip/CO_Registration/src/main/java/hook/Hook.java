package hook;

import org.aspectj.lang.annotation.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Hook {
public static WebDriver driver;
	
	
	public void initialization()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\RSHERBAH\\eclipse-workspace\\CO_Registration\\target\\chromedriver latest\\chromedriver.exe");
	    driver = new ChromeDriver();
		driver.get("http://qa.identity.metlife.co");
	}

	
	public void closedriver()
	{
		System.out.println("The browseris closing now");
		driver.quit();
	}
}
