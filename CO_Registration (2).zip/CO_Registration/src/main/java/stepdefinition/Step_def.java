package stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import hook.Hook;

public class Step_def {
	WebDriver driver = Hook.driver;

@Given("User is on login page")
public void user_is_on_login_page() {
	String title = driver.getTitle();
	System.out.println(title);
}

@Given("User click on register your account")
public void user_click_on_register_your_account() {
	try
	{
		driver.findElement(By.xpath("//a[@id=\"registerSubmit\"]")).click();
		
	}
	catch(Exception e) {
		System.out.println("Not able to click on register submit button"+e);
	}
}

@Then("User navigates to registration page")
public void user_navigates_to_registration_page() {
	try
	{
		Thread.sleep(3000);
		String expectedtitle = "Dashboard";
		String actualtitle = driver.getTitle();
		Assert.assertEquals(expectedtitle,actualtitle);
		System.out.println("You are able  to navigate to the welcome page");
		
	}
	catch(Exception e)
	{
		System.out.println("Not able to navigate to the welcome page"+e);
		Assert.fail();
	}
}



}
