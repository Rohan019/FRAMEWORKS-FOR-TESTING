package Testing.Colombia;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features ="C:\\Users\\RSHERBAH\\eclipse-workspace\\Colombia\\src\\main\\java\\Co_feature\\co_forget_password.feature" 
, glue ="co_step_def_forget_password" ,monochrome = true , plugin = {"pretty"})
public class Login_Test {
	

}
